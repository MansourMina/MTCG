﻿using MTCG.Database.Repositories.Interfaces;
using MTCG.Models;
using MTCG.Services;
using NSubstitute;

namespace MTCGTest.Services
{
    public class LoginServiceTests
    {
        private LoginService _loginService;
        private SessionService _sessionService;
        //private SessionService _sessionService;
        private IUserRepository _mockedUserRepository;

        private User CreateUser(string username, string password)
        {
            return new User(username, BCrypt.Net.BCrypt.EnhancedHashPassword(password));
        }

        [SetUp]
        public void Setup()
        {
            _mockedUserRepository = Substitute.For<IUserRepository>();
            _loginService = new LoginService(_mockedUserRepository);
            _sessionService = new SessionService(_mockedUserRepository);
        }

        [Test]
        public void Login_User_ShouldReturnToken_And_VerifySuccessfully()
        {
            // Arrange
            string username = "testUser";
            string password = "testPassword";
            var user = CreateUser(username, password);

            _mockedUserRepository.GetByName(username).Returns(user);

            // Act
            string token = _loginService.Login(username, password);
            bool verifiedToken = _sessionService.VerifyToken(token);

            // Assert
            Assert.That(token, Is.Not.Null);
            Assert.That(verifiedToken, Is.True);   
        }

        [Test]
        public void Login_User_ShouldReturnInvalidCredentials_WhenUsernameOrPasswordIsIncorrect()
        {
            // Arrange
            string username = "testUser";
            string password = "testPassword";
            string wrongPassword = "Wrong";
            var user = CreateUser(username, password);
            _mockedUserRepository.GetByName(username).Returns(user);

            // Act & Assert
            var exception = Assert.Throws<UnauthorizedAccessException>(() => _loginService.Login(username, wrongPassword));
            Assert.That(exception.Message, Is.EqualTo("Invalid username or password"));
        }

        [Test]
        public void GetSessionToken_User_ShouldReturnToken_WhenUserIsLoggedIn()
        {
            // Arrange
            string username = "testUser";
            string password = "testPassword";
            var user = CreateUser(username, password);

            _mockedUserRepository.GetByName(username).Returns(user);

            // Act
            string token = _loginService.Login(username, password);
            var loggedUserToken = _sessionService.GetSessionByUser(user.Id);

            // Assert
            Assert.That(token, Is.EqualTo(loggedUserToken));
        }

        [Test]
        public void GetSessionToken_User_ShouldReturnNull_WhenUserIsNotLoggedIn()
        {
            // Arrange
            string username = "testUser";
            string password = "testPassword";
            var user = CreateUser(username, password);

            _mockedUserRepository.GetByName(username).Returns(user);

            // Act
            var loggedUserToken = _sessionService.GetSessionByUser(user.Id);

            // Assert
            Assert.That(loggedUserToken, Is.Null);
        }

        [Test]
        public void Logout_ShouldRemoveToken_WhenTokenIsValid()
        {
            // Arrange
            string username = "testUser";
            string password = "testPassword";
            var user = CreateUser(username, password);

            _mockedUserRepository.GetByName(username).Returns(user);

            // Act
            var token = _loginService.Login(username, password);
            _loginService.Logout(token);
            bool verifiedToken = _sessionService.VerifyToken(token);
            var isLoggedIn = _sessionService.GetSessionByUser(user.Id);

            // Assert
            Assert.That(isLoggedIn, Is.Null);
            Assert.That(verifiedToken, Is.False);
        }

        [Test]
        public void GetSessionToken_ShouldReturnCorrectToken_ForMultipleUsers()
        {
            // Arrange
            var user1 = CreateUser("user1", "password1");
            var user2 = CreateUser("user2", "password2");

            _mockedUserRepository.GetByName("user1").Returns(user1);
            _mockedUserRepository.GetByName("user2").Returns(user2);

            // Act
            string token1 = _loginService.Login("user1", "password1");
            string token2 = _loginService.Login("user2", "password2");

            var sessionToken1 = _sessionService.GetSessionByUser(user1.Id);
            var sessionToken2 = _sessionService.GetSessionByUser(user2.Id);

            // Assert
            Assert.That(sessionToken1, Is.EqualTo(token1));
            Assert.That(sessionToken2, Is.EqualTo(token2));
        }

    }
}
